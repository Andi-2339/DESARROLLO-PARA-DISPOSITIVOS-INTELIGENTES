import 'dart:convert';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class BLEService {
  // Paso 6: Método para escanear dispositivos BLE
  Stream<List<ScanResult>> scanForDevices() {
    // Inicia el escaneo con un límite de tiempo
    FlutterBluePlus.startScan(timeout: const Duration(seconds: 15));
    return FlutterBluePlus.scanResults;
  }

  // Método auxiliar para detener el escaneo
  void stopScan() {
    FlutterBluePlus.stopScan();
  }

  // Paso 7: Método para conectar al dispositivo
  Future<void> connect(BluetoothDevice device) async {
    await device.connect();
  }

  // Método auxiliar para desconectar
  Future<void> disconnect(BluetoothDevice device) async {
    await device.disconnect();
  }

  // Pasos 8 y 9: Descubrir servicios y leer una característica específica
  Future<String?> readCharacteristic(
    BluetoothDevice device,
    String serviceUuid,
    String characteristicUuid,
  ) async {
    // Descubre los servicios del dispositivo
    List<BluetoothService> services = await device.discoverServices();

    for (BluetoothService service in services) {
      if (service.uuid.toString().toLowerCase() == serviceUuid.toLowerCase()) {
        for (BluetoothCharacteristic characteristic
            in service.characteristics) {
          if (characteristic.uuid.toString().toLowerCase() ==
              characteristicUuid.toLowerCase()) {
            // Lee el valor de la característica
            List<int> value = await characteristic.read();
            String decodedValue = utf8.decode(value);

            // CRITERIO DE SEGURIDAD OBLIGATORIO: Validar antes de devolver
            return _validateData(decodedValue);
          }
        }
      }
    }
    return null; // Si no encuentra el servicio o característica
  }

  // Validación de seguridad para evitar datos maliciosos o erróneos
  String? _validateData(String data) {
    try {
      // Intenta convertir el dato a número para validar la temperatura
      double temp = double.parse(data);

      // Verifica que el rango sea de -60 a 60
      if (temp >= -60 && temp <= 60) {
        return data;
      } else {
        print("Seguridad: Temperatura fuera del rango permitido (-60 a 60).");
        return null;
      }
    } catch (e) {
      // Si no es un número, asume que es texto (ej. nombre de la ciudad)
      // Verifica que la longitud del string sea menor a 50 caracteres
      if (data.length < 50) {
        return data;
      } else {
        print("Seguridad: El texto excede los 50 caracteres permitidos.");
        return null;
      }
    }
  }
}
