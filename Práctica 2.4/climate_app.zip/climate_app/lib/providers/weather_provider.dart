// lib/providers/weather_provider.dart
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart'; // <-- Importación agregada
import '../models/weather_model.dart';
import '../services/ble_service.dart'; // <-- Importación de tu nuevo servicio

class WeatherProvider extends ChangeNotifier {
  Weather? _weather;
  bool _isLoading = false;
  String? _errorMessage;
  int _tempUnit = 0; // 0 = Celsius, 1 = Fahrenheit

  // --- 1. Nuevas variables para la integración de hardware (BLE) ---
  final BLEService _bleService = BLEService();
  String _bleConnectionStatus = "Sin conexión BLE";

  // Getters originales
  Weather? get weather => _weather;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String get temperatureUnit => _tempUnit == 0 ? '°C' : '°F';

  // --- 2. Nuevo Getter para la UI ---
  String get bleConnectionStatus => _bleConnectionStatus;

  // Cargar datos (simulado)
  Future<void> loadWeather(String city) async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Future.delayed(const Duration(seconds: 1));
      _weather = Weather(
        city: city,
        temperature: 24,
        condition: 'cloudy',
        humidity: 65,
      );
    } catch (e) {
      _errorMessage = 'Error loading weather: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Cambiar unidad de temperatura
  void toggleTemperatureUnit() {
    _tempUnit = _tempUnit == 0 ? 1 : 0;
    notifyListeners();
  }

  // Actualizar temperatura manualmente
  void updateTemperature(int newTemp) {
    if (_weather != null) {
      _weather = Weather(
        city: _weather!.city,
        temperature: newTemp,
        condition: _weather!.condition,
        humidity: _weather!.humidity,
      );
      notifyListeners();
    }
  }

  // --- 3. Nuevo método: Conectar y extraer telemetría del sensor ---
  Future<void> connectAndFetchWearableData(BluetoothDevice device) async {
    _bleConnectionStatus = "Conectando..."; // Muestra estado de carga
    notifyListeners();

    try {
      await _bleService.connect(device); // Conecta al dispositivo
      _bleConnectionStatus = "Conectado a ${device.advName}";
      notifyListeners();

      // Manejo de desconexión
      device.connectionState.listen((BluetoothConnectionState state) {
        if (state == BluetoothConnectionState.disconnected) {
          _bleConnectionStatus =
              "Sin conexión BLE"; // Muestra "Sin conexion BLE" al desconectar
          notifyListeners();
        }
      });

      // UUIDs estándar GATT para Environmental Sensing
      // (Si simulas con nRF Connect, asegúrate de crear un servicio con estos UUIDs)
      String serviceUuid = "181A";
      String charUuid = "2A6E";

      // Lee la característica del wearable
      String? data = await _bleService.readCharacteristic(
        device,
        serviceUuid,
        charUuid,
      );

      if (data != null) {
        // La validación de seguridad ya ocurrió en ble_service.dart
        // Convertimos el string seguro a entero
        int sensorTemp = double.parse(data).round();

        // Mantenemos la ciudad/estado actual, pero actualizamos la temperatura física
        String currentCity = _weather?.city ?? "Sensor Local";
        String currentCondition = _weather?.condition ?? "clear";
        int currentHumidity = _weather?.humidity ?? 50;

        _weather = Weather(
          city: currentCity,
          temperature: sensorTemp,
          condition: currentCondition,
          humidity: currentHumidity,
        );

        print("Telemetría actualizada desde placa/sensor: $sensorTemp°C");
        notifyListeners();
      }
    } catch (e) {
      _bleConnectionStatus = "Error de conexión BLE";
      notifyListeners();
    }
  }
}
